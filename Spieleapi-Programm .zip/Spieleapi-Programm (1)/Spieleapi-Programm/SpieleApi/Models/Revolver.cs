﻿namespace Russian_Roulette.Models
{
    public class Revolver
    {
        public int Id { get; set; }
        public int loadedChamber { get; set; }
        public int shotChamber { get; set; }
    }
}
