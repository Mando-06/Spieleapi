﻿namespace Russian_Roulette.Models
{
    public class Punktezahl_SchereSteinPapier
    {
        public int Id { get; set; }
        public int PunkteSpieler { get; set; }
        public int PunkteBot { get; set; }
    }
}
